----------------------------------------------------------------------------
  Release notes for neutral
----------------------------------------------------------------------------

  Version:1.2

  Live demo
  http://www.mono-lab.net/demo4/

  Send me your language file!
  mail@mono-lab.net



----------------------------------------------------------------------------
  Change log
----------------------------------------------------------------------------

  ver1.2   2010/05/01 Adjust right side info and search area. (Search area will expand if you don't use social link button.)
  ver1.1.2 2010/04/30 Fixed header menu bug (this bug appear when you don't use custom header menu)
  ver1.1   2010/04/30 Add new language file
  ver1.0   2010/04/29 Released


----------------------------------------------------------------------------
  Support Languages
----------------------------------------------------------------------------
 
  English
  Japanese
  Chinese (by neverno)


----------------------------------------------------------------------------
   License
----------------------------------------------------------------------------

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.

